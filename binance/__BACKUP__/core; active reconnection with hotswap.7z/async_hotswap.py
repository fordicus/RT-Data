import asyncio, time
from dataclasses import dataclass
from typing import Optional
from util import my_name

@dataclass
class ConnectionState:
	"""연결 상태 관리"""
	task: asyncio.Task
	is_active: bool = False
	handoff_event: Optional[asyncio.Event] = None
	creation_time: float = 0.0

class HotSwapManager:
	"""진정한 Hot Swap 매니저"""
	
	def __init__(self):
		self.current_connection: Optional[ConnectionState] = None
		self.pending_connection: Optional[ConnectionState] = None
		self.swap_lock = asyncio.Lock()
		
	async def initiate_hot_swap(self, task_factory, logger):
		"""Hot swap 시작"""
		async with self.swap_lock:
			if self.pending_connection:
				return
				
			logger.info(
				f"[{my_name()}] 🔌 New Conn Start"
			)
			
			handoff_event = asyncio.Event()
			# task_factory 호출 시 올바른 순서
			new_task = asyncio.create_task(
				task_factory(handoff_event, True)  # (handoff_event, is_backup)
			)
			
			self.pending_connection = ConnectionState(
				task=new_task,
				is_active=False,
				handoff_event=handoff_event,
				creation_time=time.time()
			)

	# pending_connection 상태 확인 메서드 추가
	def is_ready_for_handoff(self) -> bool:
		return (self.pending_connection is not None and 
				not self.pending_connection.task.done())
			
	async def complete_handoff(self, logger):
		"""연결 교체 완료"""
		async with self.swap_lock:
			if not self.pending_connection:
				return
				
			logger.info(f"[{my_name()}] 🤝 Handoff")
			
			# 2. 새 연결 활성화
			self.pending_connection.is_active = True
			self.pending_connection.handoff_event.set()
			
			# 3. 기존 연결 비활성화
			if self.current_connection:
				self.current_connection.is_active = False
				
			# 4. 연결 교체
			old_connection = self.current_connection
			self.current_connection = self.pending_connection
			self.pending_connection = None
			
			# 5. 기존 연결 정리 (별도 태스크로)
			if old_connection:
				asyncio.create_task(
					self._cleanup_old_connection(old_connection, logger)
				)
				
	async def _cleanup_old_connection(self, old_conn: ConnectionState, logger):
		"""기존 연결 안전하게 정리"""
		try:
			# 잠시 대기 후 정리 (데이터 중복 방지)
			await asyncio.sleep(1.0)
			
			if not old_conn.task.done():
				old_conn.task.cancel()
				try:
					await old_conn.task
				except asyncio.CancelledError:
					pass
					
			logger.info("[HotSwap] Old connection cleaned up")
			
		except Exception as e:
			logger.warning(f"[HotSwap] Cleanup error: {e}")

async def schedule_backup_creation(
	hot_swap_manager,
	backup_start_time: float,
	task_factory,
	logger,
	back_up_ready_ahead_sec: float,
	connection_start_time: float,  # 새로 추가: 연결 시작 시간
	check_interval: float = 1.0
):
	"""지정된 시간에 백업 생성을 스케줄링"""
	
	while True:
		connection_age = time.time() - connection_start_time  # 수정됨
		
		if connection_age >= backup_start_time:
			logger.info(
				f"[{my_name()}] 🔜 Backup Scheduled / "
				f"T-{back_up_ready_ahead_sec:.2f}s / "
				f"Age {connection_age:.2f}s"
				# f"[{my_name()}] Scheduled backup creation triggered "
				# f"({back_up_ready_ahead_sec:.2f}s before refresh, "
				# f"connection age: {connection_age:.2f}s)..."
			)
			
			await hot_swap_manager.initiate_hot_swap(
				task_factory, logger
			)
			break
			
		# 1초마다 체크
		await asyncio.sleep(check_interval)